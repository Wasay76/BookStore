package Bookstore;

import Bookstore.data.Customer;
import Bookstore.data.DataManager;
import Bookstore.data.Owner;
import Bookstore.data.User;
import Bookstore.gui.CustomerStartScreen;
import Bookstore.gui.OwnerStartScreen;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class LoginScreen extends Application {

    private DataManager dataManager = new DataManager();
    private TextField usernameTextField;
    private PasswordField passwordField;
    private Label loginMessageLabel;

    @Override
    public void start(Stage stage) {
        stage.setTitle("Login Screen");

        // Create a grid pane to hold the login form
        GridPane loginForm = new GridPane();
        loginForm.setAlignment(Pos.CENTER);
        loginForm.setHgap(10);
        loginForm.setVgap(10);
        loginForm.setPadding(new Insets(25, 25, 25, 25));

        // Add welcome label to the top
        Label welcomeLabel = new Label("Welcome to the BookStore App");
        loginForm.add(welcomeLabel, 0, 0, 2, 1);

        // Create form fields and labels
        Label usernameLabel = new Label("Username:");
        loginForm.add(usernameLabel, 0, 1);
        usernameTextField = new TextField();
        loginForm.add(usernameTextField, 1, 1);

        Label passwordLabel = new Label("Password:");
        loginForm.add(passwordLabel, 0, 2);
        passwordField = new PasswordField();
        loginForm.add(passwordField, 1, 2);

        // Create login button and label for displaying login messages
        Button loginButton = new Button("Log in");
        loginForm.add(loginButton, 1, 3);
        loginMessageLabel = new Label();
        loginForm.add(loginMessageLabel, 1, 4);

        // Create a border pane to hold the login form and set it as the scene
        BorderPane root = new BorderPane();
        root.setCenter(loginForm);
        Scene scene = new Scene(root, 300, 250);
        stage.setScene(scene);

        // Set the login button action to authenticate the user
        loginButton.setOnAction(event -> {
            String username = usernameTextField.getText();
            String password = passwordField.getText();
            User user = authenticate(username, password);

            if (user == null) {
                loginMessageLabel.setText("Invalid username or password");
            } else if (user instanceof Owner) {
                loginMessageLabel.setText("Logged in as owner");
                // Open the owner dashboard
                OwnerStartScreen ownerStartScreen = new OwnerStartScreen();
                ownerStartScreen.start(stage);
            } else if (user instanceof Customer) {
                // Open the customer dashboard
                CustomerStartScreen customerStartScreen = new CustomerStartScreen(stage, (Customer) user,
                        new DataManager());
                customerStartScreen.show();
            }
        });
        dataManager.savingData(stage);
        stage.show();
    }

    // Authenticates the user based on the provided username and password
    private User authenticate(String username, String password) {
        // Authenticate as an owner
        if (username.equals(Owner.getInstance().getUsername()) && password.equals(Owner.getInstance().getPassword())) {
            return Owner.getInstance();
        }
        // Authenticate as a customer
        for (Customer customer : new DataManager().getCustomers()) {
            if (customer.getUsername().equals(username) && customer.getPassword().equals(password)) {
                return customer;
            }
        }
        // Authentication failed
        return null;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
