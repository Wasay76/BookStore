package Bookstore.gui;

import Bookstore.LoginScreen;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class OwnerStartScreen extends Application {

    private Stage stage;

    @Override
    public void start(Stage stage) {
        this.stage = stage;

        stage.setTitle("Owner Start");

        // Create buttons for Books, Customers, and Logout
        Button booksButton = new Button("Books");
        booksButton.setOnAction(e -> openBookScreen());

        Button customersButton = new Button("Customers");
        customersButton.setOnAction(e -> openCustomerScreen());

        Button logoutButton = new Button("Logout");
        logoutButton.setOnAction(e -> loginScreen());

        // Create layout for buttons
        VBox buttonLayout = new VBox();
        buttonLayout.setSpacing(10);
        buttonLayout.setPadding(new Insets(10, 10, 10, 10));
        buttonLayout.setAlignment(Pos.CENTER);
        buttonLayout.getChildren().addAll(booksButton, customersButton, logoutButton);

        // Create main layout
        VBox mainLayout = new VBox();
        mainLayout.setSpacing(10);
        mainLayout.setPadding(new Insets(10, 10, 10, 10));
        mainLayout.setAlignment(Pos.CENTER);
        mainLayout.getChildren().addAll(buttonLayout);

        // Create scene
        Scene scene = new Scene(mainLayout, 300, 200);

        // Set scene and show stage
        stage.setScene(scene);
        stage.show();
    }

    // Method for opening OwnerBookScreen
    private void openBookScreen() {
        OwnerBookScreen bookScreen = new OwnerBookScreen();
        Stage bookStage = new Stage();
        bookScreen.start(bookStage);
        stage.close();
    }

    // Method for opening OwnerCustomerScreen
    private void openCustomerScreen() {
        OwnerCustomerScreen customerScreen = new OwnerCustomerScreen();
        Stage customerStage = new Stage();
        customerScreen.start(customerStage);
        stage.close();
    }

    // Method for logout
    private void loginScreen() {
        LoginScreen loginScreen = new LoginScreen();
        Stage loginStage = new Stage();
        loginScreen.start(loginStage);
        stage.close();
    }
}
