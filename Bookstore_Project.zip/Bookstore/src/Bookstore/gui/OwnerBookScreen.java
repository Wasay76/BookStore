package Bookstore.gui;

import Bookstore.data.Book;
import Bookstore.data.DataManager;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;

public class OwnerBookScreen extends Application {

    private DataManager dataManager = new DataManager();
    private TableView<Book> table;
    private TextField nameField;
    private TextField priceField;
    private Stage stage;

    @Override
    public void start(Stage stage) {

        this.stage = stage;

        stage.setTitle("Owner Book");

        // Create table columns for book name and price
        TableColumn<Book, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        TableColumn<Book, Double> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        TableColumn<Book, Boolean> selectColumn = new TableColumn<>("Select");
        selectColumn.setCellValueFactory(cellData -> cellData.getValue().selectedProperty().asObject());
        selectColumn.setCellFactory(col -> new TableCell<Book, Boolean>() {
            private final CheckBox checkBox = new CheckBox();
            {
                checkBox.setOnAction(evt -> {
                    Book book = (Book) getTableRow().getItem();
                    book.setSelected(checkBox.isSelected());
                });
            }

            @Override
            public void updateItem(Boolean selected, boolean empty) {
                super.updateItem(selected, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(checkBox);
                    checkBox.setSelected(selected);
                }
            }
        });

        table = new TableView<>();
        table.getColumns().addAll(nameColumn, priceColumn, selectColumn);

        table.setItems(getBookData());

        // Create text fields for entering book name and price
        nameField = new TextField();
        nameField.setPromptText("Name");
        priceField = new TextField();
        priceField.setPromptText("Price");

        // Create "Add" button
        Button addButton = new Button("Add");
        addButton.setOnAction(e -> addButtonClicked());

        // Create layout for text fields and button
        HBox inputLayout = new HBox();
        inputLayout.setSpacing(10);
        inputLayout.setPadding(new Insets(10, 10, 10, 10));
        inputLayout.setAlignment(Pos.CENTER_LEFT);
        inputLayout.getChildren().addAll(nameField, priceField, addButton);

        // Create "Delete" button
        Button deleteButton = new Button("Delete");
        deleteButton.setOnAction(e -> deleteButtonClicked());

        // Create "Back" button
        Button backButton = new Button("Back");
        backButton.setOnAction(e -> backButtonClicked());

        // Create layout for delete and back buttons
        HBox buttonLayout = new HBox();
        buttonLayout.setSpacing(10);
        buttonLayout.setPadding(new Insets(10, 10, 10, 10));
        buttonLayout.setAlignment(Pos.CENTER_LEFT);
        buttonLayout.getChildren().addAll(deleteButton, backButton);

        // Create layout for table and input layout
        VBox mainLayout = new VBox();
        mainLayout.setSpacing(10);
        mainLayout.setPadding(new Insets(10, 10, 10, 10));
        mainLayout.getChildren().addAll(table, inputLayout, buttonLayout);

        // Create scene
        Scene scene = new Scene(new BorderPane(mainLayout), 550, 400);

        // Set scene and show stage
        dataManager.savingData(stage);
        stage.setScene(scene);
        stage.show();
    }

    // Method for getting book data from DataManager
    private ObservableList<Book> getBookData() {
        ObservableList<Book> bookData = FXCollections.observableArrayList();
        ArrayList<Book> books = dataManager.getBooks();
        for (Book book : books) {
            bookData.add(book);
        }
        return bookData;
    }

    // Method for handling "Add" button click event
    private void addButtonClicked() {
        // Get name and price values from text fields
        String name = nameField.getText();
        String priceStr = priceField.getText();
        if (name.isEmpty() || priceStr.isEmpty()) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error: Adding Book");
            alert.setHeaderText("Field(s) are empty");
            alert.showAndWait();
            return;
        }
        double price = Double.parseDouble(priceStr);

        // Create new book object and add to DataManager
        Book newBook = new Book(name, price);
        dataManager.addBooks(newBook);

        // Clear text fields and update table
        nameField.clear();
        priceField.clear();
        table.setItems(getBookData());
    }

    // Method for handling "Delete" button click event
    private void deleteButtonClicked() {
        ObservableList<Book> selectedBooks = table.getItems()
                .filtered(Book::isSelected);
        if (selectedBooks.isEmpty()) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error: Deleting Books");
            alert.setHeaderText("Select book to delete");
            alert.showAndWait();
            return;
        }
        // Update books file with new book data
        dataManager.removeBooks(selectedBooks);
        getBookData().removeAll(selectedBooks);
        table.setItems(getBookData());
    }

    // Method for handling "Back" button click event
    private void backButtonClicked() {
        // Create a new instance of the OwnerStartScreen class and show it
        OwnerStartScreen ownerScreen = new OwnerStartScreen();
        ownerScreen.start(stage);
    }

}
