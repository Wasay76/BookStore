package Bookstore.gui;

import java.util.ArrayList;

import Bookstore.LoginScreen;
import Bookstore.data.Book;
import Bookstore.data.Customer;
import Bookstore.data.DataManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class CustomerStartScreen {

    private DataManager dataManager = new DataManager();
    private Stage stage;
    private Customer customer;
    private TableView<Book> table;

    public CustomerStartScreen(Stage stage, Customer customer, DataManager dataManager) {
        this.stage = stage;
        this.customer = customer;

        // Create the UI elements
        Text welcome = new Text("Welcome " + customer.getUsername() + ". You have " + customer.getPoints()
                + " points. Your status is " + customer.getStatus());
        welcome.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        Text title = new Text("Books");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        TableColumn<Book, String> nameColumn = new TableColumn<>("Name");
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        TableColumn<Book, Double> priceColumn = new TableColumn<>("Price");
        priceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));
        TableColumn<Book, Boolean> selectColumn = new TableColumn<>("Select");
        selectColumn.setCellValueFactory(cellData -> cellData.getValue().selectedProperty().asObject());
        selectColumn.setCellFactory(col -> new TableCell<Book, Boolean>() {
            private final CheckBox checkBox = new CheckBox();
            {
                checkBox.setOnAction(evt -> {
                    Book book = (Book) getTableRow().getItem();
                    book.setSelected(checkBox.isSelected());
                });
            }

            @Override
            public void updateItem(Boolean selected, boolean empty) {
                super.updateItem(selected, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(checkBox);
                    checkBox.setSelected(selected);
                }
            }
        });

        table = new TableView<>();
        table.getColumns().addAll(nameColumn, priceColumn, selectColumn);

        table.setItems(getBookData());

        Button buyButton = new Button("Buy");
        buyButton.setOnAction(event -> buyBook());
        Button redeemButton = new Button("Buy and Redeem");
        redeemButton.setOnAction(event -> redeemPoints());
        Button logoutButton = new Button("Logout");
        logoutButton.setOnAction(event -> logout());

        // Layout the UI elements
        VBox vbox = new VBox();
        vbox.setSpacing(10);
        vbox.setPadding(new Insets(20));
        vbox.getChildren().addAll(welcome, title, table);
        HBox hbox = new HBox();
        hbox.setSpacing(10);
        hbox.setPadding(new Insets(20));
        hbox.setAlignment(Pos.CENTER_RIGHT);
        hbox.getChildren().addAll(buyButton, redeemButton, logoutButton);
        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(vbox);
        borderPane.setBottom(hbox);
        Scene scene = new Scene(borderPane, 500, 500);
        stage.setScene(scene);

        dataManager.savingData(stage);
    }

    private ObservableList<Book> getBookData() {
        ObservableList<Book> bookData = FXCollections.observableArrayList();
        ArrayList<Book> books = dataManager.getBooks();
        for (Book book : books) {
            bookData.add(book);
        }
        return bookData;
    }

    private void buyBook() {
        ObservableList<Book> selectedBooks = table.getItems()
                .filtered(Book::isSelected);
        if (selectedBooks.isEmpty()) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error: Buying Book");
            alert.setHeaderText("Select book to buy");
            alert.showAndWait();
            return;
        } else { // Logic for buying with money
            double totalPrice = 0.0;
            int points = customer.getPoints();
            for (Book book : table.getItems()) {
                if (book.isSelected()) {
                    totalPrice += book.getPrice();
                }
            }
            int roundedTotalPrice = (int) totalPrice;
            points += roundedTotalPrice * 10; // logic
            // Setting Points
            customer.setPoints(points);
            dataManager.updateCustomerPoints(points, customer.getUsername(),
                    customer.getPassword());
            CustomerCostScreen customerCostScreen = new CustomerCostScreen(totalPrice,
                    customer);
            customerCostScreen.start(stage);
            // Update books file with new book data
            dataManager.removeBooks(selectedBooks);
            table.setItems(getBookData());
        }
    }

    private void redeemPoints() {
        ObservableList<Book> selectedBooks = table.getItems()
                .filtered(Book::isSelected);
        if (customer.getPoints() <= 0) {
            // Show an alert if the customer's points go negative
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error: Low on Points");
            alert.setHeaderText("Insufficient Points");
            alert.showAndWait();
        } else {
            if (selectedBooks.isEmpty()) {
                // Show an alert to select at least 1 book
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error: Buying Book");
                alert.setHeaderText("Select book to buy");
                alert.showAndWait();
                return;
            } else { // Logic for buying with redeem points
                // iterate over the books in the table and buy the selected ones
                double totalPrice = 0.0;
                for (Book book : table.getItems()) {
                    if (book.isSelected()) {
                        totalPrice += book.getPrice(); // the total price of everything
                    }
                }
                int roundTotalPrice = (int) Math.floor(totalPrice);
                double storeCents = totalPrice - roundTotalPrice;
                int points = customer.getPoints();
                int counter = 0;
                while (counter != roundTotalPrice) {
                    if (customer.getPoints() <= 0) {
                        roundTotalPrice -= counter;
                        break;
                    }
                    points -= 100;
                    counter++;
                    customer.setPoints(points);
                }
                // customer.setPoints(points);
                double realTotalPrice = roundTotalPrice + storeCents;
                dataManager.updateCustomerPoints(points, customer.getUsername(),
                        customer.getPassword());
                // Update books file with new book data
                dataManager.removeBooks(selectedBooks);
                table.setItems(getBookData());
                CustomerCostScreen customerCostScreen = new CustomerCostScreen(realTotalPrice, customer);
                customerCostScreen.start(stage);
            }
        }
    }

    private void logout() {
        LoginScreen loginScreen = new LoginScreen();
        loginScreen.start(stage);
    }

    public void show() {
        stage.show();
    }
}