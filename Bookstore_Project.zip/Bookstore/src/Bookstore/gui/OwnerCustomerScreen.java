package Bookstore.gui;

import java.util.ArrayList;

import Bookstore.data.Customer;
import Bookstore.data.DataManager;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class OwnerCustomerScreen extends Application {

    private DataManager dataManager = new DataManager();
    private TableView<Customer> table;
    private TextField usernameField;
    private TextField passwordField;
    private Stage stage;

    @Override
    public void start(Stage stage) {

        this.stage = stage;

        stage.setTitle("Owner Customer");

        // Create table columns for customer username, password, points, and status
        TableColumn<Customer, String> usernameColumn = new TableColumn<>("Username");
        usernameColumn.setMinWidth(100);
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        TableColumn<Customer, String> passwordColumn = new TableColumn<>("Password");
        passwordColumn.setMinWidth(100);
        passwordColumn.setCellValueFactory(new PropertyValueFactory<>("password"));
        TableColumn<Customer, Integer> pointsColumn = new TableColumn<>("Points");
        pointsColumn.setMinWidth(50);
        pointsColumn.setCellValueFactory(new PropertyValueFactory<>("points"));
        TableColumn<Customer, Boolean> selectColumn = new TableColumn<>("Select");
        selectColumn.setCellValueFactory(cellData -> cellData.getValue().selectedProperty().asObject());
        selectColumn.setCellFactory(col -> new TableCell<Customer, Boolean>() {
            private final CheckBox checkBox = new CheckBox();
            {
                checkBox.setOnAction(evt -> {
                    Customer customer = (Customer) getTableRow().getItem();
                    customer.setSelected(checkBox.isSelected());
                });
            }

            @Override
            public void updateItem(Boolean selected, boolean empty) {
                super.updateItem(selected, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(checkBox);
                    checkBox.setSelected(selected);
                }
            }
        });

        table = new TableView<>();
        table.getColumns().addAll(usernameColumn, passwordColumn, pointsColumn, selectColumn);

        table.setItems(getCustomerData());

        // Create text fields for entering book name and price
        usernameField = new TextField();
        usernameField.setPromptText("Name");
        passwordField = new TextField();
        passwordField.setPromptText("Password");

        // Create "Add" button
        Button addButton = new Button("Add");
        addButton.setOnAction(e -> addButtonClicked());

        // Create layout for text fields and button
        HBox inputLayout = new HBox();
        inputLayout.setSpacing(10);
        inputLayout.setPadding(new Insets(10, 10, 10, 10));
        inputLayout.setAlignment(Pos.CENTER_LEFT);
        inputLayout.getChildren().addAll(usernameField, passwordField, addButton);

        // Create "Delete" button
        Button deleteButton = new Button("Delete");
        deleteButton.setOnAction(e -> deleteButtonClicked());

        // Create "Back" button
        Button backButton = new Button("Back");
        backButton.setOnAction(e -> backButtonClicked());

        // Create layout for delete and back buttons
        HBox buttonLayout = new HBox();
        buttonLayout.setSpacing(10);
        buttonLayout.setPadding(new Insets(10, 10, 10, 10));
        buttonLayout.setAlignment(Pos.CENTER_LEFT);
        buttonLayout.getChildren().addAll(deleteButton, backButton);

        // Create layout for table and input layout
        VBox mainLayout = new VBox();
        mainLayout.setSpacing(10);
        mainLayout.setPadding(new Insets(10, 10, 10, 10));
        mainLayout.getChildren().addAll(table, inputLayout, buttonLayout);

        // Create scene
        Scene scene = new Scene(new BorderPane(mainLayout), 550, 400);

        // Set scene and show stage
        dataManager.savingData(stage);
        stage.setScene(scene);
        stage.show();
    }

    // Method for getting customer data from DataManager
    private ObservableList<Customer> getCustomerData() {
        ObservableList<Customer> customerData = FXCollections.observableArrayList();
        ArrayList<Customer> customers = dataManager.getCustomers();
        for (Customer customer : customers) {
            customerData.add(customer);
        }
        return customerData;
    }

    // Method for handling "Add" button click event
    private void addButtonClicked() {
        // Get username, password, points, and status values from input fields
        String username = usernameField.getText();
        String password = passwordField.getText();
        if (username.isEmpty() || password.isEmpty()) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error: Adding Customers");
            alert.setHeaderText("Field(s) are empty");
            alert.showAndWait();
            return;
        }

        // Create new customer object and add to DataManager
        int startingPoints = 0;
        Customer newCustomer = new Customer(username, password, startingPoints);
        dataManager.addCustomers(newCustomer); // Call addCustomer method in DataManager

        // Clear input fields and update table
        usernameField.clear();
        passwordField.clear();
        table.setItems(getCustomerData());
    }

    // Method for handling "Delete" button click event
    private void deleteButtonClicked() {
        ObservableList<Customer> selectedCustomers = table.getItems()
                .filtered(Customer::isSelected);
        if (selectedCustomers.isEmpty()) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error: Deleting Customers");
            alert.setHeaderText("Select customer to delete");
            alert.showAndWait();
            return;
        }
        // Update customers file with new customer data
        dataManager.removeCustomers(selectedCustomers);
        table.setItems(getCustomerData());
    }

    // Method for handling "Back" button click event
    private void backButtonClicked() {
        // Create a new instance of the OwnerStartScreen class and show it
        OwnerStartScreen ownerScreen = new OwnerStartScreen();
        ownerScreen.start(stage);
    }

}