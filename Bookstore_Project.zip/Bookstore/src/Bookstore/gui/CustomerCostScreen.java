package Bookstore.gui;

import Bookstore.LoginScreen;
import Bookstore.data.Customer;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CustomerCostScreen extends Application {

    private double totalPrice;
    private int points;
    private String status;

    public CustomerCostScreen(double totalPrice, Customer customer) {
        this.totalPrice = totalPrice;
        this.points = customer.getPoints();
        this.status = customer.getStatus();
    }

    @Override
    public void start(Stage primaryStage) {
        // Create the main layout for the screen
        BorderPane mainLayout = new BorderPane();
        mainLayout.setPadding(new Insets(10));

        // Create the top section with the Total Cost label
        Label totalCostLabel = new Label("Total Cost: $" + totalPrice);
        totalCostLabel.setStyle("-fx-font-size: 24;");
        mainLayout.setTop(totalCostLabel);
        BorderPane.setAlignment(totalCostLabel, Pos.CENTER);

        // Create the middle section with the Points and Status labels
        Label pointsLabel = new Label("Points: " + points);
        Label statusLabel = new Label("Status: " + status);
        HBox pointsStatusBox = new HBox(20, pointsLabel, statusLabel);
        pointsStatusBox.setAlignment(Pos.CENTER);
        mainLayout.setCenter(pointsStatusBox);

        // Create the bottom section with the Logout button
        Button logoutButton = new Button("Logout");
        logoutButton.setOnAction(event -> {
            LoginScreen loginScreen = new LoginScreen();
            loginScreen.start(primaryStage);
        });
        VBox logoutBox = new VBox(logoutButton);
        logoutBox.setAlignment(Pos.CENTER);
        mainLayout.setBottom(logoutBox);

        // Create the scene and show the stage
        Scene scene = new Scene(mainLayout, 300, 200);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Customer Cost Screen");
        primaryStage.show();
    }
}