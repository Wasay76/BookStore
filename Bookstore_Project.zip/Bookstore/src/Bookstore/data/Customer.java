package Bookstore.data;

import javafx.beans.property.SimpleBooleanProperty;

/**
 * The Customer class represents a customer of the bookstore. Each customer has
 * a username, password, points, and a status.
 * The status is determined by the number of points a customer has: customers
 * with less than 1000 points are "silver" members,
 * while customers with 1000 points or more are "gold" members. Each customer
 * also has a selected property which indicates
 * whether the customer has been selected or not.
 */

public class Customer extends User {
    private int points;
    private String status;
    private SimpleBooleanProperty selected;

    public Customer(String username, String password, int points) {
        super(username, password);
        this.points = points;
        this.selected = new SimpleBooleanProperty(false);
    }

    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public String getStatus() {
        if (getPoints() < 1000) {
            status = "silver";
        } else {
            status = "gold";
        }
        return status;
    }

    public void setSelected(boolean selected) {
        this.selected.set(selected);
    }

    public boolean isSelected() {
        return selected.get();
    }

    public SimpleBooleanProperty selectedProperty() {
        return selected;
    }
}
