package Bookstore.data;

import java.util.ArrayList;

/**
 * The Owner class represents the owner of the bookstore. The owner has a
 * username and password inherited from the User class,
 * as well as two ArrayLists containing the customers and books in the
 * bookstore. There can only be one instance of the Owner class
 * in the system at any given time, and this is achieved through the use of the
 * Singleton design pattern.
 */
public class Owner extends User {
    private static Owner ownerInstance = null;
    private ArrayList<Customer> customers;
    private ArrayList<Book> books;

    private Owner() {
        super("admin", "admin");
        this.customers = new ArrayList<>();
        this.books = new ArrayList<>();
    }

    public static Owner getInstance() {
        if (ownerInstance == null) {
            ownerInstance = new Owner();
            return ownerInstance;
        }
        return ownerInstance;
    }

    public void addCustomer(Customer customer) {
        this.customers.add(customer);
    }

    public void removeCustomer(Customer customer) {
        this.customers.remove(customer);
    }

    public void addBook(Book book) {
        this.books.add(book);
    }

    public void removeBook(Book book) {
        this.books.remove(book);
    }
}
