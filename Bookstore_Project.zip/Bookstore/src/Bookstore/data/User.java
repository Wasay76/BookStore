package Bookstore.data;

/**
 * The User class represents a user of the bookstore. It is an abstract class,
 * and cannot be instantiated on its own.
 * Each user has a username and a password, which can be accessed and modified
 * through appropriate getter and setter methods.
 */
public abstract class User {
    protected String username;
    protected String password;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
