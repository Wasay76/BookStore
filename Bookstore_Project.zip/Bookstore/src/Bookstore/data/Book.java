package Bookstore.data;

import javafx.beans.property.SimpleBooleanProperty;

/**
 * The Book class represents a book in a bookstore. Each Book has a name, a
 * price, and a selected property.
 * The selected property is a boolean value indicating whether the book has been
 * selected or not.
 */
public class Book {
    private String name;
    private double price;
    private SimpleBooleanProperty selected;

    public Book(String name, double price) {
        this.name = name;
        this.price = price;
        this.selected = new SimpleBooleanProperty(false);
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public void setSelected(boolean selected) {
        this.selected.set(selected);
    }

    public boolean isSelected() {
        return selected.get();
    }

    public SimpleBooleanProperty selectedProperty() {
        return selected;
    }
}
