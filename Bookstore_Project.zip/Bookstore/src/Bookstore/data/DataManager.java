package Bookstore.data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javafx.collections.ObservableList;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * The DataManager class handles data management operations for the bookstore
 * application.
 */
public class DataManager {
    private ArrayList<Book> books = new ArrayList<>();
    private ArrayList<Customer> customers = new ArrayList<>();
    private String bookFile = "books.txt";
    private String customerFile = "customers.txt";

    /**
     * Constructor that reads data from files and initializes the books and
     * customers ArrayLists.
     */
    public DataManager() {
        readBooksDataFromFile(bookFile);
        readCustomersDataFromFile(customerFile);
    }

    /**
     * Getter method for books ArrayList.
     *
     * @return ArrayList of books
     */
    public ArrayList<Book> getBooks() {
        return books;
    }

    /**
     * Getter method for customers ArrayList.
     *
     * @return ArrayList of customers
     */
    public ArrayList<Customer> getCustomers() {
        return customers;
    }

    /**
     * Reads books data from a file and adds it to the books ArrayList.
     *
     * @param filename
     *                 name of the file to read data from
     */
    private void readBooksDataFromFile(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] bookData = line.split(",");
                String name = bookData[0];
                double price = Double.parseDouble(bookData[1]);
                books.add(new Book(name, price));
            }
        } catch (IOException e) {
            System.out.println("Files are being processed...");
        }
    }

    /**
     * Reads customer data from a file and adds it to the customers ArrayList.
     *
     * @param filename
     *                 name of the file to read data from
     */
    private void readCustomersDataFromFile(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] customerData = line.split(",");
                String username = customerData[0];
                String password = customerData[1];
                int points = Integer.parseInt(customerData[2]);
                customers.add(new Customer(username, password, points));
            }
        } catch (IOException e) {
            System.out.println("Files are being processed...");
        }
    }

    /**
     * Removes books from the books ArrayList and writes the updated list to the
     * book file.
     *
     * @param booksToRemove
     *                      list of books to be removed
     */
    public void removeBooks(ObservableList<Book> booksToRemove) {
        books.removeAll(booksToRemove);
        try {
            Files.write(Paths.get(bookFile),
                    books.stream().map(book -> book.getName() + "," + book.getPrice()).collect(Collectors.toList()));
        } catch (IOException e) {
            System.out.println("Files are being processed...");
        }
    }

    /**
     * Removes customers from the customers ArrayList and writes the updated list to
     * the customer file.
     *
     * @param customersToRemove
     *                          list of customers to be removed
     */
    public void removeCustomers(ObservableList<Customer> customersToRemove) {
        customers.removeAll(customersToRemove);
        try {
            Files.write(Paths.get(customerFile),
                    customers.stream().map(customer -> customer.getUsername() + "," + customer.getPassword() + ","
                            + customer.getPoints()).collect(Collectors.toList()));
        } catch (IOException e) {
            System.out.println("Files are being processed...");
        }
    }

    /**
     * Updates the points of a customer with the given username and password.
     *
     * @param points
     *                 new points value for the customer
     * @param username
     *                 username of the customer to be updated
     * @param password
     *                 password of the customer to be updated
     */
    public void updateCustomerPoints(int points, String username, String password) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(customerFile))) {
            for (Customer customer : customers) {
                if (customer.getUsername().equals(username) && customer.getPassword().equals(password)) {
                    customer.setPoints(points);
                }
                bw.write(customer.getUsername() + "," + customer.getPassword() + "," + customer.getPoints() + "\n");
            }
        } catch (IOException e) {
            System.out.println("Files are being processed...");
        }
    }

    /**
     * Adds a new customer to the customers ArrayList and writes the updated list to
     * the customer file.
     *
     * @param customerToAdd
     *                      customer to be added
     */
    public void addCustomers(Customer customerToAdd) {
        customers.add(customerToAdd);
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(customerFile, true))) {
            bw.write(customerToAdd.getUsername() + "," + customerToAdd.getPassword() + "," + customerToAdd.getPoints()
                    + "\n");
            removeEmptyLines(customerFile);
        } catch (IOException e) {
            System.out.println("Files are being processed...");
        }
    }

    /**
     * Adds a new book to the books ArrayList and writes the updated list to the
     * book file.
     *
     * @param bookToAdd
     *                  book to be added
     */
    public void addBooks(Book bookToAdd) {
        books.add(bookToAdd);
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(bookFile, true))) {
            bw.write(bookToAdd.getName() + "," + bookToAdd.getPrice() + "\n");
            removeEmptyLines(bookFile);
        } catch (IOException e) {
            System.out.println("Files are being processed...");
        }
    }

    /**
     * Removes empty lines from a file.
     *
     * @param filePath
     *                 path of the file to remove empty lines from
     */
    public void removeEmptyLines(String filePath) {
        try {
            List<String> lines = Files.readAllLines(Paths.get(filePath));
            List<String> newLines = new ArrayList<>();
            for (String line : lines) {
                if (!line.trim().isEmpty()) {
                    newLines.add(line);
                }
            }
            Files.write(Paths.get(filePath), newLines, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            System.out.println("Files are being processed...");
        }
    }

    /**
     * Adds a listener to the window close request event and saves data before
     * closing the application.
     *
     * @param stage
     *              stage to add listener to
     */
    public void savingData(Stage stage) {
        stage.setOnCloseRequest((WindowEvent event) -> {
            saveBooksDataToFile(bookFile);
            saveCustomersDataToFile(customerFile);
        });
    }

    /**
     * Saves the books ArrayList to a file.
     *
     * @param filename
     *                 name of the file to save data to
     */
    private void saveBooksDataToFile(String filename) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename))) {
            for (Book book : books) {
                bw.write(book.getName() + "," + book.getPrice() + "\n");
            }
        } catch (IOException e) {
            System.out.println("Files are being processed...");
        }
    }

    /**
     * Saves the customers ArrayList to a file.
     *
     * @param filename
     *                 name of the file to save data to
     */
    private void saveCustomersDataToFile(String filename) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filename))) {
            for (Customer customer : customers) {
                bw.write(customer.getUsername() + "," + customer.getPassword() + "," + customer.getPoints() + "\n");
            }
        } catch (IOException e) {
            System.out.println("Files are being processed...");
        }
    }
}
